
# Self-Driving Car Engineer Nanodegree

## Deep Learning

## Project: Build a Traffic Sign Recognition Classifier



---

## 1. The Goals of this project are the following:

* Load the "Training", "Validation" and "Test" data sets.
* Explore, visualize and summarize the data sets.
* Pre-process the data sets.
* Design, Train, Validate and Test a model architecture.
* Use the model to make predictions on new images downloaded from the web.
* Analyse the Softmax probabilities of the new images.
* Summarize the results with a written report.
* Visualize the layers of the Neural Network.

### 2. Files Submitted
* Traffic_Sign_Classifier.ipynb
* report.html
* Traffic sign images downloaded from the web
* writeup.md


```python
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
```


```python
def plot_image(length, height, image):
    plt.subplots(figsize=(length, height))
    plt.axis("off")
    plt.imshow(image)
    plt.show()
```

### 3. Dataset Exploration
#### 3.1 Dataset Summary
Exploring and analyzing the dataset is an important step before actually training the model. The following data 
provides a good overview of dataset.


Shapes of:
   > * X_train, y_train:    (34799, 32, 32, 3) (34799,)

   > * X_valid, y_valid:    (4410, 32, 32, 3) (4410,)

   > * X_test, y_test:      (12630, 32, 32, 3) (12630,)
    
   It is important to make sure that the number of training/validation/test data matches with the corresponing 
   number of expected outcome. I added the following asserts in the code (cell[2]) to confirm this.  
    
>* assert(len(X_train) == len(y_train))
>* assert(len(X_valid) == len(y_valid))
>* assert(len(X_test) == len(y_test))


*Dataset Summary:*
> * Number of training examples = 34799
> * Number of validation examples = 4410
> * Number of testing examples = 12630
> * Image data shape = (32, 32, 3)
> * Number of classes = 43


#### 3.2 Exploratory Visualization
There are 43 road signs in the input dataset. I counted the number of occurrences of each of the 43 road signs in the
training dataset of 34799 entries (cell[5]). Using these counts I added a plot to visually analyze the distribution. 


```python
signsDist = mpimg.imread("./finalReportImages/43SignDistribution.png")
plt.subplots(figsize=(24,12))
plt.axis("off")
plt.imshow(signsDist)
plt.show()
print("\033[1m                        X axis: 43 Traffic Sign Classes. Y axis: Counts of each sign in the Training Data Set")
print("\n\n")
```


![png](output_6_0.png)


    [1m                        X axis: 43 Traffic Sign Classes. Y axis: Counts of each sign in the Training Data Set
    
    
    
    

##### 3.2.1 My Observations on Exploratory Visualization
* The sign with the lowest number of occurences(180) in the X_train dataset: Class 0,  Speed limit (20km/h).
* The sign with the highest number of occurences(2010) in the X_train dataset: Class 2,  Speed limit (50km/h).
* The highest class count (2010) was more than 10 times bigger than the lowest class count (180).
* I wondered whether this wide distribution of classes would make it difficult for the model to predict some signs.

### 4. Design and Test a Model Architecture

#### 4.1 Preprocessing
I considered, implemented and experimented with the following preprocessing strategies.
Not all of them are employed in the submitted solution.

* **4.1.1 Normalize**
  > Normalization is an important step in preprocessing. It is required especially for images of varying brightness, 
    contrast and color. The function, normalize() (cell[9]) implements this functionality and is used in the final solution.


```python
normalized = mpimg.imread("./finalReportImages/normalized.png")
plot_image(12, 6, normalized)
```


![png](output_10_0.png)


* **4.1.2 Convert to Grayscale**
  > Implemted the conversion of the input images to grayscale (cell[8]). When I used this technique, my validation accuracy
    started going down. I inferred that the color images are providing more relevant information for my model 
    and kept all the input data as color images. The input images to the model have the shape 32x32x3 (instead of 
    the grayscale shape of 32x32x1)


```python
gray = mpimg.imread("./finalReportImages/grayScale.png")
plot_image(12, 6, gray)
```


![png](output_12_0.png)


* **4.1.3 Random Brightness**
  > The function random_brightness(), randomly adjusts the brightness pixels of an image up and down using 
    TensorFlow's *random_brightness()* function. I tested this function (cell[10]) with a test image and was able to verify
    the effect of this function. Since the validation accuracy reached 93.9%, I didn't employ this function in the final 
    solution.


```python
bright = mpimg.imread("./finalReportImages/randBright.png")
plot_image(12, 6, bright)
```


![png](output_14_0.png)


#### 4.2 Model Architecture
The submission provides details of the characteristics and qualities of the architecture, including 
the type of model used, the number of layers, and the size of each layer. Visualizations emphasizing 
particular qualities of the architecture are encouraged.

The starting point for the model is the LeNet-5 Convolutional Neural Network which was covered in detail in the class.
My plan was to change the model as needed based on Validation accuracy. The LeNet-5 network was chosen, since it is a 
proven model for recognizing patterns. Since we are dealing with Traffic Sign images and finding patterns is the most
important factor, I was comfortable with startign with a LeNet-5 network.


```python
print()
print("\033[1m                                  LeNet-5 Convolutional Neural Network")
leNet5 = mpimg.imread("./finalReportImages/LeNet5.png")
plot_image(18, 8, leNet5)
print("\033[1m                  Note: The Subsmapling layer shown above has been replaced with a Pooling layer.")
print("\033[1m                        A Droput layer has been added after the first Fully connected layer.")
```

    
    [1m                                  LeNet-5 Convolutional Neural Network
    


![png](output_16_1.png)


    [1m                  Note: The Subsmapling layer shown above has been replaced with a Pooling layer.
    [1m                        A Droput layer has been added after the first Fully connected layer.
    


```python
print("\033[1m                                            The elements of my Model Architecture are:")
```

    [1m                                            The elements of my Model Architecture are:
    




| Layer           | Description       |  
|:---------------:|:-----------------:| 
| Input           | 32x32x3 RGB Image | 
| Convolution 5x5 | 1x1 stride, Valid padding. Output: 28x28x6|   
| RELU            | Activation |
| Max pooling     | 2x2 stride. Output: 14x14x6 |
| Convolution 5x5 | 1x1 stride, Valid padding. Output: 10x10x16|
| RELU            | Activation    |
| Max pooling     | 2x2 stride. Output: 5x5x16 |
| Flattening      | Output: 400 |
| Fully Connected | Output: 120 |
| RELU            | Activation  |
| Droput          | Regularization. Keep probability: 0.8 |
| Fully Connected | Output: 84 |
| RELU            | Activation |    
| Fully Connected | Output: 43 |


#### 4.3 Model Training

##### 4.3.1 Optimizer

The AdamOptimizer(Adaptive Moment Estimation) was used for training. The AdamOptimizer is an efficient optimizer
that combines the elements of Momentum (moving average of the parameters) and Adagrad optimization. 

##### 4.3.2 Hyperparameters

I experimented with multiple values of the hyperparameters. The final values of the hyperparameters are:
* Epochs: 100
* Batch size: 128
* Learning rate: 0.0009
* mu: 0
* sigma: 0.1
* Keep Probability for Droput: 0.8

#### 4.4 Solutions Approach

This is the approach I took to developing and training the model:
    
* Started with LeNet5 Modelsince it was known to be good for detecting patterns (in our case, the Traffic Signs).
* The plan was to change the model as needed, based on alidation accuracy.
* For all the training runs, kept t hyperparameters "mu" as 0 and "sigma" as 0.1
* Experimented with values of "Learning rate", "Batch Size", "Epochs".
* Experimented with including and excluding Droputs.
* I was running only 10 Epochs in my local PC. Once I was condident that the Validation accuracy is increasing,
  I started running 100 Epochs in AWS instance.
* With running 100 Epochs in AWS, I was consistently getting Validation accuracy above 93%
* Overall, my approach could be summarized as "Trial and Error."

##### 4.4.1 Sample of performance logs
I kept detailed logs to track the effect of tweaking various hyperparameters and other factors such as 
Grayscale vs. Color images. Here is a subset of my training, validation logs. 

**                              Ran on my local PC with Epoch = 10**

| Image     |Epochs|Batch size| Learning rate | Mu  | Sigma | Dropout | Training accuracy | Validation accuracy | Comments |   
|:---------:|:---:|:---:|:-----:|:---:|:---:|:---:| :----:|:----:|:----:|:----:|:---:| 
| Grayscale | 10  | 128 | 0.001 | 0 | 0.1 | Not used | Not captured | 88.1% | Grayscale | 
| Color     | 10  | 128 | 0.001 | 0 | 0.1 | Not used | Not captured | 90.1% | Switched to Color | 
| Color     | 10  | 128 | 0.005 | 0 | 0.1 | Not used | Not captured | 85.6% | Increased Learning rate | 
| Color     | 20  | 128 | 0.005 | 0 | 0.1 | Not used | Not captured | 89.2% | Increased number of Epochs | 
| Color     | 10  | 128 | 0.009 | 0 | 0.1 | Not used | Not captured | 87.6% | Increased Learning rate | 
| Color     | 10  | 128 | 0.009 | 0 | 0.1 | 0.5      | Not captured | 86.4% | Added Dropout after Fullyconnected layer 1 (Fc1)| 
| Color     | 10  | 128 | 0.001 | 0 | 0.1 | 0.5      | Not captured | 81.6% | Added second Droput after Fullyconnected 2 (Fc2)|  
| Color     | 30  | 200 | 0.009 | 0 | 0.1 | 0.5      | Not captured | 87.8% | Incresed Epochs, Batch size and one Droput after FC1| 
| Color     | 10  | 128 | 0.0009| 0 | 0.1 | Not used | 98.4%        | 89.5% | Started calculating Training accuracy  
| Color     | 10  | 128 | 0.0009| 0 | 0.1 | Not used | 98.4%        | 89.5% |       |
| Color     | 10  | 128 | 0.0009| 0 | 0.1 | 0.8      | 96.6%        | 88.3% | Added Dropout after Fullyconnected layer 1 

**                             Ran on AWS Instance with Epoch = 100**

| Image     |Epochs|Batch size| Learning rate | Mu  | Sigma | Dropout | Training accuracy | Validation accuracy | Comments |   
|:---------:|:---:|:---:|:-----:|:---:|:---:|:---:| :----:|:----:|:----:|:----:|:---:| 
| Color | 10  | 128 | 0.0009| 0 | 0.1 | Not used | Not captured | 86.5% |  First time running on AWS.
| Color | 100 | 128 | 0.001 | 0 | 0.1 | Not used | Not captured | 94.0% |  With 100 Epochs,Validation accuracy: 94%
| Color | 10  | 128 | 0.0009| 0 | 0.1 | Not used | 98.7%        | 91.2% |  Started calculating Training accuracy  
| Color | 100 | 128 | 0.0009| 0 | 0.1 | Not used | 100%         | 94.1% |                  |
| Color | 100 | 128 | 0.0009| 0 | 0.1 | 0.8      | 99.6%        | 93.4% |  Added Dropout after Fc1. Final submitted version


#### 4.5 My Observations on Model Architecture
This section summarizes my overall observations for the entire preprocessing, training and validation phase. 

* **Color vs. Greyscale** I had better validation accuracy with color images. I inferred taht the model is able to
    detect patterns better with the additional information provided by the colore images. I decided to keep the 
    input images as color images.
* **Learning rate** Varying the the Learning rate had the maximum effect on Validation accuracy.
* **Dropout** Dropout is a "Regularization" technique to avoid "Overfitting". When I introduced "dropout" after both  
    the Fully connected layers, the Validation accuracy dropped below 93%. When I used just one Droput, after the 
    Fully connected layer the Validation accuracy stayed above 93%. 
* **Using AWS** On my local PC, the maximum I was able ro run was around 10 Epochs. I could see the Validation accuracy 
    increasing but never reached the required accuracy of 93%. Very soon, I realized that I need to run more Epochs and 
    started using AWS. Running 100 Epochs on AWS quickly brought the Validation accuracy to above 93%    
* After experimenting with various preprocessing and Dropouts, my final solution added a single Dropout function to the 
 LeNet-5 model.

### 5. Test Model on New Images

#### 5.1 Acquiring New Images
I downloaded 5 images of the "German Traffic signs" from the web. They were of varying sizes and the traffic signs were not 
at the center of the image. As the first step, I cropped  the images to make sure the traffic sign is at the center. 
Then, i resized the images to 32x32 pixels using Paint. My first observation was that the downloaded images are much 
brighter than the training set images. I thought having a bright image will help predict the image correctly. 

##### 5.1.1 Selection of New Images
When I first analzyed the distribution of the count of the Traffic Sign classes (please refer the diagram titled
**Distribution of 43 signsin X_train**), I thought the model will have difficulty in correctly predicting those signs 
with the least amount of counts. So, I made sure I select the sign with the least number of counts in X_train. That is
the sign"Speed limit (20km/h)". 


```python
# Downloaded images after they are cropped (to keep the sign at the center) and resized.
print()
print("\033[1m                        Downloaded German Traffic Signs after they were Cropped and Resized")
image = mpimg.imread("./finalReportImages/downloadedCroppedResized.png")
plot_image(18,12,image)
```

    
    [1m                        Downloaded German Traffic Signs after they were Cropped and Resized
    


![png](output_25_1.png)


#### 5.2 Performance on New Images
The results of the prediction

| Image        | Prediction|  
|--------------|:---------:| 
| Ahead only| Ahead only  | 
| Vehicles over 3.5 metric tons prohibited | Vehicles over 3.5 metric tons prohibited|   
| Stop            | Stop|
| Road work   | Road work |
| Speed limit (20km/h) | Turn left ahead|

The prediction accuracy the new images is 80% (4 out of 5 correct).

The model's 
     Training accuracy = 99.6%'
     Validation accuracy = 93.4%
     Test accuracy = 91.1%
    
There could be multiple reasons for this.
* The number of new images is only 5. A large number new images would have a much higher prediction accuracy.
* The one image that was predicted wrong, Speed limit (20km/h) has the least number of occurrences in the training data set.
* All the downloaded images are bright but I don't think this will make the prediction wrong.'
            

#### 5.3 Model Certainty - Softmax Probabilities
In this section, we review how certain the model was when predicting the 5 downloaded images.
The following cell displays the sign along with a corrsponding bar chart that shows the Softmax probability.
In the subsequent cell, the top 5 probabilities are discussed.


```python
image = mpimg.imread("./finalReportImages/signsBar.png")
plot_image(36,24,image)
```


![png](output_28_0.png)


For **Ahead only** sign, the model is pretty sure about the prediction. 

The top 5 sign predictions and their probabilities are as follows:

|   | Class ID | Sign Name| Probabilities |
|---|--------------|:---------:|-----------| 
| 1 | 35 | Ahead only | 1.000000e+00 
| 2 | 33 | Turn right ahead | 1.307069e-13 | 
| 3 | 34 | Turn left ahead | 7.898958e-14 |
| 4 | 40 | Roundabout mandatory   | 1.299796e-14 |
| 5 | 38 | Keep right | 3.862057e-15|

It is interesting to note that the 2nd and 3rd highest probabilities are Turn right ahead and Turn left ahead which 
have similar characteristics to the Ahead only sign. We can see that thw model is doing a very good job.

For **Vehicles over 3.5 metric tons prohibited** sign, the model has a high confidence for the prediction. 

The top 5 sign predictions and their probabilities are as follows:

|   | Class ID | Sign Name| Probabilities |
|---|--------------|:---------:|-----------| 
| 1 | 16 | Vehicles over 3.5 metric tons prohibited | 9.999305e-01 
| 2 |  5 | Speed limit (80km/h)| 6.944372e-05 | 
| 3 |  7 | Speed limit (100km/h) | 3.237496e-11 |
| 4 |  6 | End of speed limit (80km/h)   | 4.384266e-12 |
| 5 | 32 | End of all speed and passing limits | 3.683759e-14|

It is interesting to note that the 2nd and 3rd probabilities are Turn right ahead and Turn left ahead which have similar
characteristics to the Ahead only sign. We can see that the model is doing a very good job.

For the **Stop** sign, the model has a high confidence in predicting it as a Stop sign with a probability of 1.

The top 5 sign predictions and their probabilities are as follows:

|   | Class ID | Sign Name| Probabilities |
|---|--------------|:---------:|-----------| 
| 1 | 14 | Stop |  1.000000e+00
| 2 | 13 | Yield| 1.215875e-09 | 
| 3 | 17 | No entry  |  2.230951e-10 |
| 4 | 25 | Road work | 4.453972e-13|
| 5 |  1 | Speed limit (30km/h) | 3.563120e-13|


For the **Road work** sign, the model has a high confidence in predicting it as a "Road work" sign with a probability of 1.

The top 5 sign predictions and their probabilities are as follows:
    

|   | Class ID | Sign Name| Probabilities |
|---|--------------|:---------:|-----------| 
| 1 | 25 |  Road work |  1.000000e+00
| 2 | 20 | Dangerous curve to the right| 2.096266e-23 | 
| 3 | 31 | Wild animals crossing  |  8.820190e-31|
| 4 | 11 | Right-of-way at the next intersection | 5.272261e-32|
| 5 | 24 | Road narrows on the right | 2.488332e-32  |


The model predicted the **Speed limit 20(km/h)** sign, wrong. It should be noted that the first prediction 
has probability of only 0.92 compared to probability 1 for all the other 4 signs.

The top 5 sign predictions and their probabilities are as follows:
    
|   | Class ID | Sign Name| Probabilities |
|---|--------------|:---------:|-----------| 
| 1 | 34 |  Turn left ahead|  0.922388
| 2 |  3 | Speed limit (60km/h)| 0.062827 | 
| 3 | 13 |  Yield  |  0.014721|
| 4 | 23 |  Slippery road | 0.000062|
| 5 | 11 | Right-of-way at the next intersection   |  0.000001 |


### 6. Visualize the Neural Network's State

To visualize the feature maps of the Neural Network, a test image is fed through the trained network. The plot of the 
output of the network's weight layers help us to look at the feature map. 


```python
print()
print("\033[1m Test image used for visualizing the Neural Network. Dimensions: 32x32x3")
test_image = mpimg.imread("./finalReportImages/visualTest.png")
plot_image(9,4.5,test_image)
```

    
    [1m Test image used for visualizing the Neural Network. Dimensions: 32x32x3
    


![png](output_36_1.png)



```python
print()
print("\033[1m                      The 6 Feature maps of the first convolutional layer. Dimensions: 28x28x6")
test_image = mpimg.imread("./finalReportImages/visualCnn-1.png")
plot_image(24,12,test_image)
```

    
    [1m                      The 6 Feature maps of the first convolutional layer. Dimensions: 28x28x6
    


![png](output_37_1.png)


The 6 FeatureMaps of the first convolutional layer shown above, detects simple chractersitics of the image. For example,
3 of the FeatureMaps, (0,4,5), detect the edge of the traffic sign. The FeatureMap seem to detect the edge of the arrow 
in the sign. 


```python
print()
print("\033[1m                          The 16 Feature maps of the second convolutional layer. Dimensions: 10x10x16")
test_image = mpimg.imread("./finalReportImages/visualCnn-2.png")
plot_image(28,14,test_image)
```

    
    [1m                          The 16 Feature maps of the second convolutional layer. Dimensions: 10x10x16
    


![png](output_39_1.png)


The 16 FeatureMaps of the second convolutional layer, detects the next level of complex characteristics of the sign.
Since the dimension of the FearureMaps is 10x10, these FeatureMaps provide a detailed, zoomed ib view of the sign.
For example, FeatureMap2 seem to be detecting the edge of the arrow for the Ahead only sign.

